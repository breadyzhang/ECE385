This lab is expected to get full credit for the week 1 demo and 3 points for the week 2 demo.

The project is able to show a correct output in the simulation [testbench] of the decrytion, but it is unable to be sent through the
NIOS II-e and displayed on the terminal.  However, the benchmark does work and shows the AES decryption speed, and it is 
significantly faster than the software speed.